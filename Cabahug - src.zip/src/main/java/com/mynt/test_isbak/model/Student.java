package com.mynt.test_isbak.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity //mark class as entity
@Table //defining class name as Table name
@Getter
@Setter
public class Student {

    @Column //defining id as primary key
    @Id
    public Long id;

    @Column
    public String name;

    @Column
    public Integer age;

    @Column
    public String email;
}