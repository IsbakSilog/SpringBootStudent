package com.mynt.test_isbak.repository;

import com.mynt.test_isbak.model.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository extends CrudRepository<Student, Long> {
}
