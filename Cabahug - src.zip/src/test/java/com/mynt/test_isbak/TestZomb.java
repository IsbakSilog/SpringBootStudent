package com.mynt.test_isbak;

public class TestZomb {
    public static void main(String[] args) {
        Zombie zombie = new Zombie(3,"brainless");
       // zombie.setTeeth(3);
        System.out.println(zombie.getTeeth() +" "+ zombie.getBrains());
    }
}
