    package com.mynt.test_isbak;

    import lombok.AllArgsConstructor;
    import lombok.Getter;
    //import lombok.NoArgsConstructor;
    import lombok.Setter;

    @Getter
    @AllArgsConstructor
    @Setter


    public class Zombie {

        private int teeth;
        private String brains;


    }
