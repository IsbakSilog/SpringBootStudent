package com.mynt.test_isbak;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class HelloController {

    @GetMapping("/test")
    public String index() {
        return "Greetings from Spring Boot!";
    }
    @GetMapping("/zombie")
    public String test() {
        Zombie z = new Zombie(4,"brainless");

        return "This is your zombie" + " " + z.getBrains() +" " + z.getTeeth();

    }
    @GetMapping("/cash")
    public List<Cash> cash(){
        List<Cash> list =new ArrayList();
        list.add(new Cash(4 ,"Dollar"));
        list.add(new Cash(69, "Euro"));
        return list;
    }
}
